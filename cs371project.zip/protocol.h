
#ifndef protocol_h
#define protocol_h


struct User {
	unsigned int clientID;
	char username[MAX_USERNAME];
};

#endif
