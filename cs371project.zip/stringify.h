#ifndef STRINGIFY_H
#define STRINGIFY_H

#define stringify(x)        stringify_helper(x)
#define stringify_helper(x) #x

#endif
